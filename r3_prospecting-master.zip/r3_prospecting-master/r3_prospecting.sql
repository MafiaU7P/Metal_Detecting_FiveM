INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
	('bones', 'Bones', 100, 0, 1),
	('detector', 'Metal Detector', 2000, 0, 1),
	('dragon_scales', 'Dragon Scales', 1000, 0, 1),
	('gold_ring', 'Gold Ring', 100, 0, 1),
	('metalscrap', 'Metal Scrap', 100, 0, 1),
	('nuts_and_bolts', 'Nuts and Bolts', 100, 0, 1);
