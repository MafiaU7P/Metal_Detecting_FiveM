Config = {}

-- Prospecting blip
Config.ProspectingBlipText = "Prospecting"
Config.ProspectingBlipSprite = 485
